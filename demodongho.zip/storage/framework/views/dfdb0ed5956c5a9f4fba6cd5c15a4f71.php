<?php $__env->startSection('admin_content'); ?>

<div class="panel panel-default">
    <div class="panel-heading">
        Thêm người dùng
    </div>
    <div class="panel-body">
        <form action="<?php echo e(route('admin.users.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <div class="form-group">
                <label>Họ tên</label>
                <input type="text" name="fullname" class="form-control" required>
            </div>

            <div class="form-group">
                <label>Email</label>
                <input type="email" name="email" class="form-control" required>
            </div>

            <div class="form-group">
                <label>Mật khẩu</label>
                <input type="password" name="password" class="form-control" required>
            </div>

            <!-- <div class="form-group">
                <label>Số điện thoại</label>
                <input type="text" name="phone" class="form-control">
            </div>

            <div class="form-group">
                <label>Địa chỉ</label>
                <input type="text" name="address" class="form-control">
            </div> -->

            <div class="form-group">
                <label>Phân quyền</label>
                <select name="role_id" class="form-control" required>
                    <option value="">-- Chọn quyền --</option>
                    <option value="2">Khách hàng</option>
                    <option value="1">Admin Coder</option>
                    <option value="3">Giám đốc</option>
                    <option value="4">Nhân viên bán hàng</option>
                    <option value="5">Nhân viên kho</option>
                </select>
            </div>

            <button type="submit" class="btn btn-info">
                Thêm người dùng
            </button>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.admin_layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\demodongho\resources\views/admin/users/add_admin_user.blade.php ENDPATH**/ ?>