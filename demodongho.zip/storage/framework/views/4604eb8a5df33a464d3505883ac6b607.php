<?php $__env->startSection('admin_content'); ?>

<div class="panel panel-default">

    
    <div class="panel-heading">
        Danh sách đánh giá sản phẩm
        <?php if(isset($filterStatus) && $filterStatus == 1): ?>
            <small>(Trạng thái: Hiển thị)</small>
        <?php elseif(isset($filterStatus) && $filterStatus === "0"): ?>
            <small>(Trạng thái: Ẩn)</small>
        <?php endif; ?>
    </div>

    
    <div class="row" style="padding: 10px 15px;">
        <div class="col-sm-4">
            <form method="GET" action="<?php echo e(route('admin.reviewuser.index')); ?>" class="form-inline">
            <select name="status" class="form-control input-sm">
                <option value="">Lọc trạng thái (Tất cả)</option>
                <option value="1" <?php echo e(isset($filterStatus) && $filterStatus == 1 ? 'selected' : ''); ?>>
                    Hiển thị
                </option>
                <option value="0" <?php echo e(isset($filterStatus) && $filterStatus == 0 ? 'selected' : ''); ?>>
                    Ẩn
                </option>
            </select>
                <button type="submit" class="btn btn-sm btn-default" style="margin-left:5px;">
                    Áp dụng
                </button>
            </form>
        </div>
    </div>

    
    <div class="table-responsive">
        <table class="table table-striped table-bordered">
            <thead style="background:#f5f5f5;">
                <tr>
                    <th>ID</th>
                    <th>Người đánh giá</th>
                    <th>Sản phẩm</th>
                    <th>Số sao</th>
                    <th>Nội dung</th>
                    <th>Trạng thái</th>
                    <th>Thao tác</th>
                    <th>Ngày</th>
                    <th>Gộp</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($key + 1); ?></td>

                    
                    <td><?php echo e($review->user->fullname ?? 'Không xác định'); ?></td>

                    
                    <td><?php echo e($review->product->name ?? 'Đã xoá'); ?></td>

                    
                    <td style="color:#e60012;font-weight:600;">
                        <?php echo e($review->rating); ?> ★
                    </td>

                    
                    <td style="max-width:300px;">
                        <?php echo e($review->comment); ?>

                    </td>
                    
                    <td>
                        <?php if($review->status == 1): ?>
                            <span class="label label-success">Hiển thị</span>
                        <?php else: ?>
                            <span class="label label-default">Ẩn</span>
                        <?php endif; ?>
                    </td>

                    
                    <td>
                        <?php if($review->status == 1): ?>
                            <a href="<?php echo e(route('admin.review.toggle', $review->id)); ?>"
                               class="btn btn-warning btn-xs">
                                Ẩn đánh giá
                            </a>
                        <?php else: ?>
                            <a href="<?php echo e(route('admin.review.toggle', $review->id)); ?>"
                               class="btn btn-success btn-xs">
                                Hiển thị
                            </a>
                        <?php endif; ?>
                    </td>

                    
                    <td>
                        <?php echo e($review->created_at->format('d/m/Y H:i')); ?>

                    </td>
                    <td><?php echo e($review->rating); ?> ★,
                    <?php echo e($review->created_at->format('d/m/Y H:i')); ?>

                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="8" class="text-center">
                        Chưa có đánh giá nào
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    
    <footer class="panel-footer">
      <div class="row">
        <div class="col-sm-5 text-center">
          <small class="text-muted inline m-t-sm m-b-sm">
            Hiển thị <?php echo e($reviews->firstItem()); ?> - <?php echo e($reviews->lastItem()); ?>

            / <?php echo e($reviews->total()); ?> Comment
          </small>
        </div>

        <div class="text-center">
          <?php echo e($reviews->links('vendor.pagination.number-only')); ?>

        </div>
      </div>
    </footer>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('pages.admin_layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\demodongho\resources\views/admin/reviews_user/index.blade.php ENDPATH**/ ?>