<?php $__env->startSection('admin_content'); ?>

<div class="table-agile-info">
  <div class="panel panel-default">

    
    <div class="panel-heading" style="color:#000; font-weight:600;">
      <?php if(isset($currentStatus)): ?>
          <?php if($currentStatus == 'pending'): ?>      Hàng Chưa Bán Trong Kho
          <?php elseif($currentStatus == 'selling'): ?>  Hàng Đang Bán Trong Kho
          <?php elseif($currentStatus == 'sold_out'): ?> Hàng Bán Hết Trong Kho
          <?php elseif($currentStatus == 'stopped'): ?>  Hàng Ngừng Bán Trong Kho
          <?php endif; ?>
      <?php else: ?>
          Quản Lý Kho Hàng (Của Các Lô)
      <?php endif; ?>
    </div>

    
    <?php if(session('success')): ?>
      <div class="alert alert-success" style="margin:15px;">
        <?php echo e(session('success')); ?>

      </div>
    <?php endif; ?>

    
    <div class="row w3-res-tb" style="padding: 0 15px; margin-top: 15px;">
      <div class="col-sm-5 m-b-xs">
        <form method="GET" action="<?php echo e(route('admin.storage-details.index')); ?>" class="form-inline">

          
          <select name="storage_id" class="input-sm form-control w-sm inline v-middle">
            <option value="">Lọc theo lô (Tất cả)</option>
            <?php $__currentLoopData = $storages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $st): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($st->id); ?>"
                <?php echo e(isset($selectedStorageId) && $selectedStorageId == $st->id ? 'selected' : ''); ?>>
                <?php echo e($st->batch_code); ?>

              </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>

          
          <button type="submit" class="btn btn-sm btn-default" style="margin-left:5px;">
            Áp dụng
          </button>

        </form>
      </div>

      <div class="col-sm-4"></div>
    </div>

    
    <div class="table-responsive" style="margin-top:10px;">
      <style>
          table td, table th {
              text-align: center !important;
              vertical-align: middle !important;
          }
      </style>

      <table class="table table-striped b-t b-light">
        <thead>
          <tr>
            <th>ID</th>
            <th>Mã lô</th>
            <th>Tên sản phẩm</th>
            <th>Số lượng nhập</th>
            <th>SL đang bán</th>
            <th>SL đã bán</th>
            <th>Trạng thái kho</th>
            <th>Hiển thị</th>
            <th style="width:150px;">Thao tác</th>
          </tr>
        </thead>

        <tbody>
          <?php $__empty_1 = true; $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php
              $sellingQty = (int)($detail->selling_qty ?? 0);
              $soldQty    = (int)($detail->sold_qty ?? 0);
            ?>

            <tr>
              <td><?php echo e($detail->id); ?></td>

              
              <td><?php echo e(optional($detail->storage)->batch_code ?? '—'); ?></td>

              
              <td><?php echo e($detail->product_name); ?></td>

              
              <td><?php echo e(number_format($detail->import_quantity)); ?></td>

              
              <td><?php echo e(number_format($sellingQty)); ?></td>

              
              <td><?php echo e(number_format($soldQty)); ?></td>

              
              <td>
                <?php if($detail->stock_status === 'pending'): ?>
                  <span class="label label-warning">Chờ bán</span>
                <?php elseif($detail->stock_status === 'selling'): ?>
                  <span class="label label-success">Đang bán</span>
                <?php elseif($detail->stock_status === 'sold_out'): ?>
                  <span class="label label-default">Hết hàng</span>
                <?php elseif($detail->stock_status === 'stopped'): ?>
                  <span class="label label-danger">Ngừng bán</span>
                <?php else: ?>
                  <span class="label label-default">—</span>
                <?php endif; ?>
              </td>

              
              <td>
                <?php if($detail->status): ?>
                  <span class="label label-success">Hiện</span>
                <?php else: ?>
                  <span class="label label-default">Ẩn</span>
                <?php endif; ?>
              </td>

              
              <td>
                
                <a href="<?php echo e(route('admin.storage-details.edit', $detail->id)); ?>"
                   title="Sửa"
                   style="margin-right:6px;">
                  <i class="fa fa-pencil-square-o text-success" style="font-size:18px;"></i>
                </a>

                
                <form action="<?php echo e(route('admin.storage-details.toggle-status', $detail->id)); ?>"
                      method="POST"
                      style="display:inline-block; margin-right:6px;">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('PATCH'); ?>
                  <button type="submit"
                          title="<?php echo e($detail->status ? 'Ẩn' : 'Hiện'); ?>"
                          style="background:none; border:none; padding:0;">
                    <?php if($detail->status): ?>
                      <i class="fa fa-eye-slash text-warning" style="font-size:18px;"></i>
                    <?php else: ?>
                      <i class="fa fa-eye text-warning" style="font-size:18px;"></i>
                    <?php endif; ?>
                  </button>
                </form>

                
                <?php if($detail->storage): ?>
                  <a href="<?php echo e(route('admin.storage-details.by-storage', $detail->storage->id)); ?>"
                     title="Xem lô"
                     style="margin-right:6px;">
                    <i class="fa fa-database" style="font-size:18px;"></i>
                  </a>
                <?php endif; ?>

                
                <?php if($detail->product): ?>
                  <a href="<?php echo e(route('admin.products.show', $detail->product->id)); ?>"
                     title="Xem sản phẩm đã đăng bán">
                    <i class="fa fa-cubes text-info" style="font-size:18px;"></i>
                  </a>
                <?php else: ?>
                  <a href="#"
                     onclick="alert('Sản phẩm này chưa được đăng bán'); return false;"
                     title="Sản phẩm này chưa được đăng bán">
                    <i class="fa fa-cubes text-muted" style="font-size:18px;"></i>
                  </a>
                <?php endif; ?>
              </td>
            </tr>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
              <td colspan="9" class="text-center">Kho đang trống.</td>
            </tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>

    <footer class="panel-footer">
      <div class="row">
        <div class="col-sm-5 text-center">
          <small class="text-muted inline m-t-sm m-b-sm">
            Hiển thị <?php echo e($details->firstItem()); ?> - <?php echo e($details->lastItem()); ?>

            / <?php echo e($details->total()); ?> lô hàng
          </small>
        </div>

        <div class="text-center">
          <?php echo e($details->links('vendor.pagination.number-only')); ?>

        </div>
      </div>
    </footer>

  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.admin_layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\demodongho\resources\views/admin/storage_details/index_all.blade.php ENDPATH**/ ?>