<?php $__env->startSection('admin_content'); ?>

<?php
    $currentAdminId   = (int) Session::get('admin_id');
    $currentAdminRole = (int) Session::get('admin_role_id');
?>

<div class="panel panel-default">

    
    <div class="panel-heading">
        Danh sách nhân sự
        <?php if(isset($filterStatus) && $filterStatus == 1): ?>
            <small>(Trạng thái: Hoạt động)</small>
        <?php elseif(isset($filterStatus) && $filterStatus === "0"): ?>
            <small>(Trạng thái: Đình chỉ)</small>
        <?php endif; ?>
    </div>

    
    <div class="row" style="padding: 10px 15px;">
        <div class="col-sm-4">
            <form method="GET" action="<?php echo e(route('admin.staff.index')); ?>" class="form-inline">
                <select name="status" class="form-control input-sm">
                    <option value="">Lọc trạng thái (Tất cả)</option>
                    <option value="1" <?php echo e((string)$filterStatus === "1" ? 'selected' : ''); ?>>
                        Đang hoạt động
                    </option>
                    <option value="0" <?php echo e((string)$filterStatus === "0" ? 'selected' : ''); ?>>
                        Bị đình chỉ
                    </option>
                </select>

                <button type="submit" class="btn btn-sm btn-default" style="margin-left:5px;">
                    Áp dụng
                </button>
            </form>
        </div>
    </div>

    
    <div class="table-responsive">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th style="width:60px">ID</th>
                    <th>Họ tên</th>
                    <th>Email</th>
                    <th>Vai trò</th>
                    <th>Phân quyền</th>
                    <th>Trạng thái</th>
                    <th style="width:140px">Thao tác</th>
                </tr>
            </thead>
            <tbody>

                <?php $__empty_1 = true; $__currentLoopData = $staffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($staff->id); ?></td>
                        <td><?php echo e($staff->fullname); ?></td>
                        <td><?php echo e($staff->email); ?></td>

                        
                        <td>
                            <?php switch($staff->role_id):
                                case (1): ?> Admin Coder <?php break; ?>
                                <?php case (3): ?> Giám đốc <?php break; ?>
                                <?php case (4): ?> Nhân viên bán hàng <?php break; ?>
                                <?php case (5): ?> Nhân viên kho <?php break; ?>
                            <?php endswitch; ?>
                        </td>

                        
                        <td>
                            <?php if($currentAdminRole === 1 && $staff->id !== $currentAdminId): ?>
                                <form action="<?php echo e(route('admin.staff.updateRole', $staff->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <select name="role_id"
                                            class="form-control input-sm"
                                            onchange="this.form.submit()">

                                        <option value="1" <?php echo e($staff->role_id == 1 ? 'selected' : ''); ?>>
                                            Admin Coder
                                        </option>
                                        <option value="3" <?php echo e($staff->role_id == 3 ? 'selected' : ''); ?>>
                                            Giám đốc
                                        </option>
                                        <option value="4" <?php echo e($staff->role_id == 4 ? 'selected' : ''); ?>>
                                            Nhân viên bán hàng
                                        </option>
                                        <option value="5" <?php echo e($staff->role_id == 5 ? 'selected' : ''); ?>>
                                            Nhân viên kho
                                        </option>
                                    </select>
                                </form>
                            <?php else: ?>
                                <span class="text-muted">
                                    <?php switch($staff->role_id):
                                        case (1): ?> Admin Coder <?php break; ?>
                                        <?php case (3): ?> Giám đốc <?php break; ?>
                                        <?php case (4): ?> NV Bán hàng <?php break; ?>
                                        <?php case (5): ?> NV Kho <?php break; ?>
                                    <?php endswitch; ?>
                                </span>
                            <?php endif; ?>
                        </td>

                        
                        <td>
                            <?php if($staff->status == 1): ?>
                                <span class="label label-success">Hoạt động</span>
                            <?php else: ?>
                                <span class="label label-danger">Bị đình chỉ</span>
                            <?php endif; ?>
                        </td>

                        
                        <td>
                            <?php
                                $isSelf = ($staff->id === $currentAdminId);
                            ?>

                            <?php if($staff->status == 1): ?>
                                <button
                                    class="btn btn-warning btn-xs btn-change-status"
                                    data-url="<?php echo e(route('admin.staff.unactive', $staff->id)); ?>"
                                    data-action="đình chỉ"
                                    data-self="<?php echo e($isSelf ? 1 : 0); ?>"
                                    data-role="<?php echo e($staff->role_id); ?>"
                                >
                                    Đình chỉ
                                </button>
                            <?php else: ?>
                                <button
                                    class="btn btn-success btn-xs btn-change-status"
                                    data-url="<?php echo e(route('admin.staff.active', $staff->id)); ?>"
                                    data-action="kích hoạt"
                                    data-self="<?php echo e($isSelf ? 1 : 0); ?>"
                                    data-role="<?php echo e($staff->role_id); ?>"
                                >
                                    Kích hoạt
                                </button>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="text-center text-muted">
                            Không có nhân sự
                        </td>
                    </tr>
                <?php endif; ?>

            </tbody>
        </table>
    </div>

    
    <footer class="panel-footer">
        <div class="row">
            <div class="col-sm-5 text-center">
                <small class="text-muted inline m-t-sm m-b-sm">
                    Hiển thị <?php echo e($staffs->firstItem()); ?> - <?php echo e($staffs->lastItem()); ?>

                    / <?php echo e($staffs->total()); ?> tài khoản
                </small>
            </div>

            <div class="col-sm-7 text-center">
                <?php echo e($staffs->links('vendor.pagination.number-only')); ?>

            </div>
        </div>
    </footer>

</div>
<script>
document.addEventListener('DOMContentLoaded', function () {

    document.querySelectorAll('.btn-change-status').forEach(function (btn) {
        btn.addEventListener('click', function () {

            const url    = this.dataset.url;
            const action = this.dataset.action;
            const isSelf = this.dataset.self === "1";
            const role   = parseInt(this.dataset.role);

            // TỰ ĐÌNH CHỈ CHÍNH MÌNH
            if (isSelf) {
                Swal.fire({
                    icon: 'error',
                    title: 'Không được phép',
                    text: 'Bạn không thể đình chỉ hoặc kích hoạt chính mình.',
                    confirmButtonText: 'OK'
                });
                return;
            }

            // KHÔNG ĐƯỢC ĐÌNH CHỈ ADMIN CODER
            if (role === 1) {
                Swal.fire({
                    icon: 'error',
                    title: 'Bị chặn',
                    text: 'Không thể đình chỉ Admin Coder.',
                    confirmButtonText: 'OK'
                });
                return;
            }

            // XÁC NHẬN HÀNH ĐỘNG
            Swal.fire({
                title: 'Xác nhận',
                text: `Bạn có chắc muốn ${action} nhân sự này?`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Đồng ý',
                cancelButtonText: 'Hủy'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = url;
                }
            });
        });
    });

});
</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.admin_layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\demodongho\resources\views/admin/staff/all_staff_user.blade.php ENDPATH**/ ?>