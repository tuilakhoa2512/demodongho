<?php $__env->startSection('content'); ?>

<h2 class="title text-center">Sản phẩm yêu thích của bạn</h2>
 
<div class="features_items">

<?php
    $favorite_ids = $favorites->pluck('product_id')->toArray();
?>

<?php $__empty_1 = true; $__currentLoopData = $favorites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fav): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

    <?php if($fav->product): ?>
        <?php echo $__env->make('pages.partials.product_card', [
            'product' => $fav->product,
            'favorite_ids' => $favorite_ids
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endif; ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col-sm-12">
            <p class="text-center" style="font-size:16px;">
                Hiện chưa có sản phẩm nào yêu thích
            </p>
        </div>
   
<?php endif; ?>

<div class="clearfix"></div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\demodongho\resources\views/favorite/indexfavorite.blade.php ENDPATH**/ ?>