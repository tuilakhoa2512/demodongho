<?php $__env->startSection('admin_content'); ?>

<div class="table-agile-info">
  <div class="panel panel-default">

    <div class="panel-heading" style="font-size: 18px; font-weight: 600;">
      DANH SÁCH SẢN PHẨM
    </div>

    
    <?php if(session('success')): ?>
      <script>
          Swal.fire({
              title: "Thành công!",
              text: "<?php echo e(session('success')); ?>",
              icon: "success",
              confirmButtonText: "OK",
          });
      </script>
    <?php endif; ?>

    
    <?php if(session('error')): ?>
      <script>
          Swal.fire({
              icon: 'error',
              title: 'Không thể thực hiện!',
              text: '<?php echo e(session("error")); ?>',
              confirmButtonText: "OK"
          });
      </script>
    <?php endif; ?>

    
    <div class="row w3-res-tb">
      <div class="col-sm-5 m-b-xs">
        <select class="input-sm form-control w-sm inline v-middle">
          <option value="0">Thao tác</option>
          <option value="1">Xóa đã chọn (chưa làm)</option>
          <option value="2">Xuất Excel (chưa làm)</option>
        </select>
        <button class="btn btn-sm btn-default">Áp dụng</button>
      </div>

      <div class="col-sm-3"></div>

      <div class="col-sm-4">
        <div class="input-group">
          
        </div>
      </div>
    </div>

    <div class="table-responsive">

      <style>
          table td, table th {
              text-align: center !important;
              vertical-align: middle !important;
          }
      </style>

      <table class="table table-striped b-t b-light">
        <thead>
          <tr>
            <th style="width:20px;">
              <label class="i-checks m-b-none">
                <input type="checkbox"><i></i>
              </label>
            </th>
            <th>ID</th>
            <th>Hình</th>
            <th>Tên sản phẩm</th>
            <th>Số lượng tồn kho</th>
            <th>Giá bán</th>

            <th>Ưu đãi</th>
            <th>Giá sau ưu đãi</th>

            <th>Trạng thái bán</th>
            <th>Hiển Thị</th>
            <th style="width:140px;">Thao tác</th>
          </tr>
        </thead>

        <tbody>
          <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php
              $storageDetail = optional($product->storageDetail);
              $storage       = optional($storageDetail->storage);

              // ✅ NEW promotion fields from controller (PromotionService)
              $hasPromo = !empty($product->promo_has_sale);
              $finalPrice = isset($product->final_price) ? (float)$product->final_price : (float)$product->price;
              $promoName = $product->promo_name ?? null;
              $promoLabel = $product->promo_label ?? null;
            ?>

            <tr>
              <td>
                <label class="i-checks m-b-none">
                  <input type="checkbox" name="product_ids[]" value="<?php echo e($product->id); ?>"><i></i>
                </label>
              </td>

              <td><?php echo e($product->id); ?></td>

              <td>
                <?php if($product->productImage && $product->productImage->image_1): ?>
                  <img src="<?php echo e(asset('storage/' . $product->productImage->image_1)); ?>"
                       alt="<?php echo e($product->name); ?>"
                       style="width: 60px; height: 60px; object-fit: cover; border-radius:4px;">
                <?php else: ?>
                  <span>Không có ảnh</span>
                <?php endif; ?>
              </td>

              <td><?php echo e($product->name); ?></td>

              <td><?php echo e(number_format($product->quantity)); ?></td>

              <td>
                <div style="line-height:1.2;">
                  <div style="font-weight:800;">
                    <?php echo e(number_format($product->price, 0, ',', '.')); ?> đ
                  </div>
                </div>
              </td>

              
              <td>
                <?php if($hasPromo): ?>
                  <span class="label label-info">
                    <?php echo e($promoName ?? 'Ưu đãi'); ?>

                    <?php if(!empty($promoLabel)): ?>
                      (<?php echo e($promoLabel); ?>)
                    <?php endif; ?>
                  </span>
                <?php else: ?>
                  —
                <?php endif; ?>
              </td>

              
              <td>
                <?php if($hasPromo): ?>
                  <strong style="color:#e60012;">
                    <?php echo e(number_format($finalPrice, 0, ',', '.')); ?> đ
                  </strong>
                <?php else: ?>
                  —
                <?php endif; ?>
              </td>

              <td>
                <?php if($product->stock_status === 'selling'): ?>
                  <span class="label label-success">Đang bán</span>
                <?php elseif($product->stock_status === 'sold_out'): ?>
                  <span class="label label-default">Hết hàng</span>
                <?php elseif($product->stock_status === 'stopped'): ?>
                  <span class="label label-danger">Ngừng bán</span>
                <?php else: ?>
                  <span class="label label-default">—</span>
                <?php endif; ?>
              </td>

              <td>
                <?php if($product->status): ?>
                  <span class="label label-success">Hiện</span>
                <?php else: ?>
                  <span class="label label-default">Ẩn</span>
                <?php endif; ?>
              </td>

              <td>

                <form action="<?php echo e(route('admin.products.toggle-status', $product->id)); ?>"
                      method="POST"
                      style="display:inline-block; margin-right:6px;">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('PATCH'); ?>
                  <button type="submit"
                          style="border:none; background:none; padding:0;"
                          title="<?php echo e($product->status ? 'Ẩn sản phẩm' : 'Hiển thị sản phẩm'); ?>">
                    <?php if($product->status): ?>
                      <i class="fa fa-eye-slash text-warning" style="font-size:18px;"></i>
                    <?php else: ?>
                      <i class="fa fa-eye text-warning" style="font-size:18px;"></i>
                    <?php endif; ?>
                  </button>
                </form>

                <a href="<?php echo e(route('admin.products.show', $product->id)); ?>"
                   title="Xem chi tiết"
                   style="margin-right:6px;">
                  <i class="fa fa-info-circle text-info" style="font-size:18px;"></i>
                </a>

                <?php if($storage && $storage->id): ?>
                  <a href="<?php echo e(route('admin.storage-details.by-storage', $storage->id)); ?>"
                     title="Xem sản phẩm trong lô <?php echo e($storage->batch_code); ?>">
                    <i class="fa fa-archive text-primary" style="font-size:18px;"></i>
                  </a>
                <?php else: ?>
                  <span title="Không tìm thấy lô hàng">
                    <i class="fa fa-archive text-muted" style="font-size:18px; opacity:0.5;"></i>
                  </span>
                <?php endif; ?>

              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
              <td colspan="11" class="text-center">Chưa có sản phẩm nào.</td>
            </tr>
          <?php endif; ?>

        </tbody>
      </table>
    </div>

    <footer class="panel-footer">
      <div class="row">

        <div class="col-sm-5 text-center">
          <?php if($products->total() > 0): ?>
            <small class="text-muted inline m-t-sm m-b-sm">
              Hiển thị <?php echo e($products->firstItem()); ?> - <?php echo e($products->lastItem()); ?>

              / <?php echo e($products->total()); ?> sản phẩm
            </small>
          <?php else: ?>
            <small class="text-muted inline m-t-sm m-b-sm">
              Không có sản phẩm nào.
            </small>
          <?php endif; ?>
        </div>

        <div class="col-sm-7 text-right text-center-xs">
          <?php echo e($products->links('vendor.pagination.number-only')); ?>

        </div>

      </div>
    </footer>

  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.admin_layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\demodongho\resources\views/admin/products/index.blade.php ENDPATH**/ ?>