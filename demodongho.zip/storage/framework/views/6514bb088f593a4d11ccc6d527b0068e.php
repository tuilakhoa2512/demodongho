<?php $__env->startSection('content'); ?>

<div class="container" style="margin-top:50px;">
    <div class="row">

        <!-- CONTENT SAU SIDEBAR -->
        <div class="col-sm-12 col-md-9 col-lg-9">

            <div class="register-form">

                <h2 class="title text-center mb-4">ĐĂNG KÝ</h2>

                <div class="register-inner">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger text-center">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div><?php echo e($err); ?></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
                
                    <form action="<?php echo e(URL::to('/add-user')); ?>" method="POST">
                        <?php echo csrf_field(); ?>

                        <div class="form-group">
                            <label>Họ và tên</label>
                            <input type="text" name="fullname"
                                   class="form-control"
                                   placeholder="Nguyễn Văn A"
                                   required>
                        </div>

                        <div class="form-group">
                            <label>Email</label>
                            <input type="email" name="email"
                                   class="form-control"
                                   placeholder="xxx@gmail.com"
                                   required>
                        </div>

                        <div class="form-group">
                            <label>Mật khẩu</label>
                            <input type="password" name="password"
                                   id="password"
                                   class="form-control"
                                   required>
                        </div>

                        <div class="form-group">
                            <label>Xác nhận mật khẩu</label>
                            <input type="password"
                                   name="password_confirmation"
                                   id="password_confirmation"
                                   class="form-control"
                                   required>
                            <small id="password-match-message"></small>
                        </div>

                        <div class="form-group">
                            <label>Số điện thoại</label>
                            <input type="text" name="phone"
                                   class="form-control"
                                   required>
                        </div>

                        <button type="submit" class="register-btn">
                            Đăng ký
                        </button>
                    </form>

                    <div class="mt-4 text-center">
                        Đã có tài khoản?
                        <a href="<?php echo e(url('/login-checkout')); ?>" style="color:blue;font-weight:bold;">
                            Đăng nhập
                        </a>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>


<!-- JS KIỂM TRA KHỚP MẬT KHẨU -->
<script>
document.addEventListener('DOMContentLoaded', function () {
    const password = document.getElementById('password');
    const confirm  = document.getElementById('password_confirmation');
    const message  = document.getElementById('password-match-message');

    function checkMatch() {
        if (!confirm.value) {
            message.textContent = '';
            return;
        }

        if (password.value === confirm.value) {
            message.textContent = '✔ Mật khẩu khớp';
            message.style.color = 'green';
        } else {
            message.textContent = '✖ Mật khẩu không khớp';
            message.style.color = 'red';
        }
    }

    password.addEventListener('keyup', checkMatch);
    confirm.addEventListener('keyup', checkMatch);
});
</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\demodongho\resources\views/pages/checkout/register.blade.php ENDPATH**/ ?>