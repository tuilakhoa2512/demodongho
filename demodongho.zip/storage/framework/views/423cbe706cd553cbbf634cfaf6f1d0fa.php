<?php $__env->startSection('content'); ?>

<h2 class="title text-center">
    SẢN PHẨM ĐANG GIẢM GIÁ
</h2>

<div class="features_items">
    <div class="row">

        <?php $__empty_1 = true; $__currentLoopData = $saleProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php echo $__env->make('pages.partials.product_card', [
                'product' => $product,                
            ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-sm-12">
                <p class="text-center" style="font-size:16px;">
                    Hiện chưa có sản phẩm nào đang giảm giá
                </p>
            </div>
        <?php endif; ?>
    </div>
</div>

<div class="text-center">
    <?php echo e($saleProducts->links('vendor.pagination.number-only')); ?>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\demodongho\resources\views/pages/sales.blade.php ENDPATH**/ ?>