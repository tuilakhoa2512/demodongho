<?php $__env->startSection('admin_content'); ?>

<div class="table-agile-info">
  <div class="panel panel-default">

    <div class="panel-heading" style="font-size:18px; font-weight:600;">
      QUẢN LÝ ƯU ĐÃI (CAMPAIGNS)
    </div>

    
    <?php if(session('success')): ?>
      <script>
        Swal.fire({ title:"Thành công!", text:"<?php echo e(session('success')); ?>", icon:"success", confirmButtonText:"OK" });
      </script>
    <?php endif; ?>
    <?php if(session('error')): ?>
      <script>
        Swal.fire({ icon:"error", title:"Không thể thực hiện!", text:"<?php echo e(session('error')); ?>", confirmButtonText:"OK" });
      </script>
    <?php endif; ?>

    
    <div class="row w3-res-tb" style="margin-bottom:10px;">
      <div class="col-sm-12">
        <form method="GET" action="<?php echo e(route('admin.promotions.index')); ?>" class="form-inline" style="display:flex; gap:10px; flex-wrap:wrap;">
          <select name="status" class="form-control input-sm">
            <option value="">-- Trạng thái: tất cả --</option>
            <option value="1" <?php echo e((string)($status ?? '') === '1' ? 'selected' : ''); ?>>Hiện</option>
            <option value="0" <?php echo e((string)($status ?? '') === '0' ? 'selected' : ''); ?>>Ẩn</option>
          </select>

          <input type="text" name="q" class="form-control input-sm"
                 placeholder="Tìm theo tên chiến dịch..."
                 value="<?php echo e($q ?? ''); ?>" style="min-width:260px;">

          <button class="btn btn-sm btn-default" type="submit">Lọc</button>

          <a href="<?php echo e(route('admin.promotions.create')); ?>" class="btn btn-sm btn-primary" style="margin-left:auto;">
            <i class="fa fa-plus"></i> Thêm Chiến Dịch
          </a>
        </form>
      </div>
    </div>

    <div class="table-responsive">
      <style>
        table td, table th { text-align:center !important; vertical-align:middle !important; }
        .text-left { text-align:left !important; }
      </style>

      <table class="table table-striped b-t b-light">
        <thead>
          <tr>
            <th>ID</th>
            <th class="text-left">Tên Chiến Dịch</th>
            <th>Thời gian</th>
            <th>Độ Ưu Tiên</th>
            <th>Rules</th>
            <th>Trạng Thái</th>
            <th style="width:140px;">Thao Tác</th>
          </tr>
        </thead>

        <tbody>
          <?php $__empty_1 = true; $__currentLoopData = $campaigns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php
              $timeText = '—';
              if ($c->start_at || $c->end_at) {
                $timeText =
                  ($c->start_at ? \Carbon\Carbon::parse($c->start_at)->format('d/m/Y H:i') : '…')
                  . ' → ' .
                  ($c->end_at ? \Carbon\Carbon::parse($c->end_at)->format('d/m/Y H:i') : '…');
              }
              $ruleCount = isset($c->rules_count) ? (int)$c->rules_count : (isset($c->rules) ? $c->rules->count() : 0);
            ?>

            <tr>
              <td><?php echo e($c->id); ?></td>

              <td class="text-left" style="font-weight:700;">
                <?php echo e($c->name); ?>

                <?php if(!empty($c->description)): ?>
                  <div style="color:#777; font-weight:400; font-size:12px; margin-top:3px;">
                    <?php echo e(\Illuminate\Support\Str::limit($c->description, 90)); ?>

                  </div>
                <?php endif; ?>
              </td>

              <td style="font-size:12px;"><?php echo e($timeText); ?></td>

              <td><?php echo e((int)($c->priority ?? 0)); ?></td>

              <td><span class="label label-info"><?php echo e($ruleCount); ?></span></td>

              <td>
                <?php if($c->status): ?>
                  <span class="label label-success">Hiện</span>
                <?php else: ?>
                  <span class="label label-default">Ẩn</span>
                <?php endif; ?>
              </td>

              <td>
                <a href="<?php echo e(route('admin.promotions.edit', $c->id)); ?>"
                   class="btn btn-xs" 
                  style="background:none; border:none;"
                   title="Sửa Campaign + quản lý Rules/Targets/Codes">
                  <i class="fa fa-pencil-square-o text-success text-active" style="font-size:18px;"></i>
                </a>

                <form action="<?php echo e(route('admin.promotions.toggle-status', $c->id)); ?>"
                      method="POST"
                      style="display:inline-block;">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>

                    <button type="submit"
                            style="border:none; background:none; padding:0;"
                            title="<?php echo e($c->status ? 'Ẩn khuyến mãi' : 'Hiển thị khuyến mãi'); ?>">

                        <?php if($c->status): ?>
                            <i class="fa fa-eye-slash text-warning" style="font-size:18px;"></i>
                        <?php else: ?>
                            <i class="fa fa-eye text-warning" style="font-size:18px;"></i>
                        <?php endif; ?>

                    </button>
                </form>

              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
              <td colspan="7" class="text-center">Chưa có campaign nào.</td>
            </tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>

    <footer class="panel-footer">
      <div class="row">
        <div class="col-sm-5 text-center">
          <?php if($campaigns->total() > 0): ?>
            <small class="text-muted inline m-t-sm m-b-sm">
              Hiển thị <?php echo e($campaigns->firstItem()); ?> - <?php echo e($campaigns->lastItem()); ?>

              / <?php echo e($campaigns->total()); ?> campaign
            </small>
          <?php else: ?>
            <small class="text-muted inline m-t-sm m-b-sm">Không có campaign nào.</small>
          <?php endif; ?>
        </div>

        <div class="col-sm-7 text-right text-center-xs">
          <?php echo e($campaigns->links('pagination::bootstrap-4')); ?>

        </div>
      </div>
    </footer>

  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.admin_layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\demodongho\resources\views/admin/promotions/index.blade.php ENDPATH**/ ?>