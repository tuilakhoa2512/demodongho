<?php $__env->startSection('admin_content'); ?>

<div class="panel panel-default">

    <div class="panel-heading">
        Danh sách người dùng
        <?php if(isset($filterStatus) && $filterStatus == 1): ?>
            <small>(Trạng thái: Hiện)</small>
        <?php elseif(isset($filterStatus) && $filterStatus === "0"): ?>
            <small>(Trạng thái: Ẩn)</small>
        <?php endif; ?>
    </div>

    
    <?php if(session('message')): ?>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            Swal.fire({
                icon: 'success',
                title: 'Thành công!',
                text: '<?php echo e(session('message')); ?>',
                confirmButtonText: 'OK'
            });
        });
    </script>
    <?php endif; ?>

    
    <div class="row" style="padding: 10px 15px;">
        <div class="col-sm-4">
            <form method="GET" action="<?php echo e(route('admin.users.index')); ?>" class="form-inline">
                <select name="status" class="form-control input-sm">
                    <option value="">Lọc trạng thái (Tất cả)</option>
                    <option value="1" <?php echo e(isset($filterStatus) && $filterStatus == 1 ? 'selected' : ''); ?>>
                        Đang Hoạt động
                    </option>
                    <option value="0" <?php echo e(isset($filterStatus) && $filterStatus == 0 ? 'selected' : ''); ?>>
                        Bị đình chỉ
                    </option>
                </select>

                <button type="submit" class="btn btn-sm btn-default" style="margin-left:5px;">
                    Áp dụng
                </button>
            </form>
        </div>
    </div>

    
    <div class="table-responsive">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Họ tên</th>
                    <th>Email</th>
                    <th>Trạng thái</th>
                    <th>Thao tác</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($user->id); ?></td>
                    <td><?php echo e($user->fullname); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td>
                        <?php if($user->status == 1): ?>
                            <span class="label label-success">Hoạt động</span>
                        <?php else: ?>
                            <span class="label label-danger">Bị dình chỉ</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($user->status == 1): ?>
                            <a href="<?php echo e(route('admin.users.unactive', $user->id)); ?>"
                               class="btn btn-warning btn-xs">
                                Đình chỉ hoạt động
                            </a>
                        <?php else: ?>
                            <a href="<?php echo e(route('admin.users.active', $user->id)); ?>"
                               class="btn btn-success btn-xs">
                                Kích hoạt lại
                            </a>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>


<footer class="panel-footer">
      <div class="row">
        <div class="col-sm-5 text-center">
          <small class="text-muted inline m-t-sm m-b-sm">
            Hiển thị <?php echo e($users->firstItem()); ?> - <?php echo e($users->lastItem()); ?>

            / <?php echo e($users->total()); ?> Tài Khoản
          </small>
        </div>

        <div class="col-sm-7 text-right text-center-xs">
          <?php echo e($users->links('vendor.pagination.number-only')); ?>

        </div>
      </div>
    </footer>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.admin_layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\demodongho\resources\views/admin/users/all_admin_user.blade.php ENDPATH**/ ?>