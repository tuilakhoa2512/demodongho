<?php $__env->startSection('admin_content'); ?>

<?php
    $storageDetail = optional($product->storageDetail);
    $storage       = optional($storageDetail->storage);
    $images        = $product->productImage;

    //  NEW: ƯU ĐÃI (PromotionService gắn runtime từ controller)
    $hasPromo   = !empty($product->promo_has_sale);
    $promoName  = $product->promo_name ?? null;
    $promoLabel = $product->promo_label ?? null;

    // final_price luôn fallback về price để view không bị null
    $finalPrice = isset($product->final_price) ? (float)$product->final_price : (float)$product->price;

    // Nếu muốn “chắc chắn” là có giảm thật mới hiện giá sau ưu đãi:
    $showFinalPrice = $hasPromo && ($finalPrice < (float)$product->price);
?>



<div class="row">
    <div class="col-lg-12">

        <section class="panel">
            <header class="panel-heading" style="color:#000; font-weight:600;">
                Chi tiết sản phẩm: <?php echo e($product->name); ?>

            </header>

            <div class="panel-body">

                
                <h4 class="product-section-title">Ảnh sản phẩm</h4>

                <div class="row" style="margin-bottom:20px;">
                    <?php $__currentLoopData = [1,2,3,4]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $field = "image_{$i}"; ?>
                        <div class="col-md-3 col-sm-6" style="margin-bottom:15px; text-align:center;">

                            <?php if($images && $images->$field): ?>
                                <img src="<?php echo e(asset('storage/' . $images->$field)); ?>"
                                     class="product-image-large">
                            <?php else: ?>
                                <div style="
                                    width:100%;
                                    height:260px;
                                    border:1px dashed #ccc;
                                    border-radius:6px;
                                    display:flex;
                                    align-items:center;
                                    justify-content:center;
                                    color:#aaa;">
                                    Không có ảnh
                                </div>
                            <?php endif; ?>

                            <div style="margin-top:5px; font-size:13px;">
                                Ảnh <?php echo e($i); ?>

                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                
                <h4 class="product-section-title">Thông tin sản phẩm</h4>

                <div class="row">

                    
                    <div class="col-md-6">
                        <div class="well" style="padding:12px 15px;">

                            <div class="info-row">
                                <div class="info-label">Tên sản phẩm</div>
                                <div><?php echo e($product->name); ?></div>
                            </div>

                            <div class="info-row">
                                <div class="info-label">Giá bán</div>
                                <div><?php echo e(number_format($product->price, 0, ',', '.')); ?> đ</div>
                            </div>

                            
                            <div class="info-row">
                                <div class="info-label">Ưu đãi</div>
                                <div>
                                    <?php if($hasPromo): ?>
                                        <span class="label label-info">
                                            <?php echo e($promoName ?? 'Ưu đãi'); ?>

                                            <?php if(!empty($promoLabel)): ?>
                                                (<?php echo e($promoLabel); ?>)
                                            <?php endif; ?>
                                        </span>
                                    <?php else: ?>
                                        —
                                    <?php endif; ?>
                                </div>
                            </div>

                            
                            <div class="info-row">
                                <div class="info-label">Giá sau ưu đãi</div>
                                <div>
                                    <?php if($showFinalPrice): ?>
                                        <strong style="color:#e60012;">
                                            <?php echo e(number_format($finalPrice, 0, ',', '.')); ?> đ
                                        </strong>
                                    <?php else: ?>
                                        —
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="info-row">
                                <div class="info-label">Số lượng tồn kho</div>
                                <div><?php echo e($product->quantity); ?></div>
                            </div>

                            <div class="info-row">
                                <div class="info-label">Trạng thái bán</div>
                                <div>
                                    <?php if($product->stock_status === 'selling'): ?>
                                        <span class="badge-status label label-success">Đang bán</span>
                                    <?php elseif($product->stock_status === 'sold_out'): ?>
                                        <span class="badge-status label label-default">Hết hàng</span>
                                    <?php else: ?>
                                        <span class="badge-status label label-danger">Ngừng bán</span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="info-row">
                                <div class="info-label">Hiển thị</div>
                                <div>
                                    <?php if($product->status): ?>
                                        <span class="badge-status label label-success">Hiện</span>
                                    <?php else: ?>
                                        <span class="badge-status label label-default">Ẩn</span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="info-row">
                                <div class="info-label">Loại đồng hồ</div>
                                <div><?php echo e(optional($product->category)->name ?? '—'); ?></div>
                            </div>

                            <div class="info-row">
                                <div class="info-label">Thương hiệu</div>
                                <div><?php echo e(optional($product->brand)->name ?? '—'); ?></div>
                            </div>

                            <div class="info-row">
                                <div class="info-label">Giới tính</div>
                                <div>
                                    <?php if($product->gender === 'male'): ?> Nam
                                    <?php elseif($product->gender === 'female'): ?> Nữ
                                    <?php elseif($product->gender === 'unisex'): ?> Unisex
                                    <?php else: ?> —
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="info-row">
                                <div class="info-label">Kích thước mặt</div>
                                <div><?php echo e($product->dial_size ? $product->dial_size . ' mm' : '—'); ?></div>
                            </div>

                            <div class="info-row">
                                <div class="info-label">Chất liệu dây</div>
                                <div><?php echo e($product->strap_material ?? '—'); ?></div>
                            </div>

                        </div>
                    </div>

                    
                    <div class="col-md-6">
                        <h6 class="product-section-title">Mô tả sản phẩm</h6>
                        <div class="well" style="height:100%; background:#f9f9f9; padding:12px 15px;">
                            <?php echo nl2br(e($product->description ?: 'Chưa có mô tả.')); ?>

                        </div>
                    </div>

                </div>

                
                <h4 class="product-section-title">Thông tin Lô / Kho</h4>

                <div class="well" style="padding:12px 15px;">

                    <div class="info-row">
                        <div class="info-label">Mã lô</div>
                        <div><?php echo e($storage->batch_code ?? '—'); ?></div>
                    </div>

                    <div class="info-row">
                        <div class="info-label">Tên trong kho</div>
                        <div><?php echo e($storageDetail->product_name ?? '—'); ?></div>
                    </div>

                    <div class="info-row">
                        <div class="info-label">Số lượng nhập</div>
                        <div><?php echo e($storageDetail->import_quantity); ?></div>
                    </div>

                </div>


                
                <div style="margin-top:15px;">
                    <a href="<?php echo e(route('admin.products.edit', $product->id)); ?>" class="btn btn-primary">
                        <i class="fa fa-pencil"></i> Sửa sản phẩm
                    </a>

                    <a href="<?php echo e(route('admin.products.index')); ?>" class="btn btn-default">
                        <i class="fa fa-arrow-left"></i> Quay lại danh sách
                    </a>
                </div>

            </div>
        </section>
    </div>
</div>

<style>
    .product-section-title {
        font-size: 18px;
        font-weight: 600;
        margin-bottom: 10px;
    }
    .product-image-large {
        width: 100%;
        height: 260px;
        object-fit: cover;
        border-radius: 6px;
        border: 1px solid #ccc;
    }
    .info-row {
        display: flex;
        border-bottom: 1px solid #eee;
        padding: 6px 0;
    }
    .info-label {
        font-weight: 600;
        width: 180px;
    }
    .badge-status {
        padding: 4px 10px;
        border-radius: 12px;
        font-size: 12px;
    }
</style>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.admin_layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\demodongho\resources\views/admin/products/show.blade.php ENDPATH**/ ?>