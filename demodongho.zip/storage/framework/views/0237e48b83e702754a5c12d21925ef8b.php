<?php $__env->startSection('admin_content'); ?>

<div class="table-agile-info">
  <div class="panel panel-default">
    <div class="panel-heading">
      Liệt Kê Thương Hiệu Sản Phẩm
      <?php if($filterStatus == 1): ?>
          <small>(Trạng Thái: Hiện)</small>
        <?php elseif($filterStatus === "0"): ?>
          <small>(Trạng Thái: Ẩn)</small>
        <?php endif; ?>
    </div>
          <?php if(session('message')): ?>
                            <script>
                                $(document).ready(function() {
                                    Swal.fire({
                                        icon: 'success',
                                        title: 'Thành công!',
                                        text: '<?php echo e(session('message')); ?>',
                                        confirmButtonText: 'OK'
                                    });
                                });
                            </script>
                        <?php endif; ?>

    <div class="row w3-res-tb">
      <div class="col-sm-5 m-b-xs">
      <form method="GET" action="<?php echo e(route('admin.allbrandproduct')); ?>" class="form-inline">
          <select name="status" class="input-sm form-control w-sm inline v-middle">
            <option value="">Lọc trạng thái (Tất cả)</option>
            <option value="1" <?php echo e(isset($filterStatus) && $filterStatus == 1 ? 'selected' : ''); ?>>Hiện</option>
            <option value="0" <?php echo e(isset($filterStatus) && $filterStatus == 0 ? 'selected' : ''); ?>>Ẩn</option>
          </select>

          <button type="submit" class="btn btn-sm btn-default" style="margin-left:5px;">
            Áp dụng
          </button>

        </form>
        
      </div>
      <div class="col-sm-4"></div>
      <div class="col-sm-3">
        <div class="input-group">
   
        </div>
      </div>
    </div>

    <div class="table-responsive">

      <table class="table table-striped b-t b-light">
        <thead>
          <tr>
            <th style="width:20px;">
              <label class="i-checks m-b-none">
                <input type="checkbox"><i></i>
              </label>
            </th>
            <th>ID</th>
            <th>Tên thương hiệu</th>
            <th>Mô tả</th>
            <th>Slug</th>
            <th>Hình</th>
            <th>Hiển Thị</th>
            <th>Thao tác</th>
            <th style="width:30px;"></th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $all_brand_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $brand_pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td>
              <label class="i-checks m-b-none">
                <input type="checkbox" name="post[]"><i></i>
              </label>
            </td>

            <td><?php echo e($brand_pro->id); ?></td>
            <td><?php echo e($brand_pro->name); ?></td>
            <td><?php echo e($brand_pro->description); ?></td>
            <td><?php echo e($brand_pro->brand_slug); ?></td>
            <td>
              <?php if($brand_pro->image): ?>
                <img src="<?php echo e(asset('storage/' . $brand_pro->image)); ?>"
                     alt="<?php echo e($brand_pro->name); ?>"
                     style="width: 50px; height: 50px; object-fit: cover;">
              <?php else: ?>
                <span>Chưa có ảnh</span>
              <?php endif; ?>
            </td>
              <td>
                <span class="text-ellipsis">
                <?php if($brand_pro->status == 1): ?>
                        <span class="label label-success">Hiện</span>
                <?php else: ?>
                        <span class="label label-danger">Ẩn</span>
                <?php endif; ?>
                </span>
              </td>
              <td>
               <a href="<?php echo e(URL::to('/edit-brand-product/'.$brand_pro->id)); ?>" class="active styling edit">
               <i class="fa fa-pencil-square-o text-success text-active"></i>
                </a>
                <!-- Ẩn / Hiện -->
                <?php if($brand_pro->status == 1): ?>
                    <!-- Đang hiện → cho phép chuyển sang Ẩn -->
                    <a href="<?php echo e(URL::to('/unactive-brand-product/'.$brand_pro->id)); ?>"
                      class="active styling edit"
                      style="font-size: 18px;">
                        <i class="fa fa-eye text-warning"></i>
                    </a>
                <?php else: ?>
                    <!-- Đang ẩn → cho phép chuyển sang Hiện -->
                    <a href="<?php echo e(URL::to('/active-brand-product/'.$brand_pro->id)); ?>"
                      class="active styling edit"
                      style="font-size: 18px;">
                        <i class="fa fa-eye-slash text-warning"></i>
                    </a>
                <?php endif; ?>
              </td>
            </td>
          </tr>
          
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>

    <footer class="panel-footer">
      <div class="row">
        <div class="col-sm-5 text-center">
          <small class="text-muted inline m-t-sm m-b-sm">
            Hiển thị <?php echo e($all_brand_product->firstItem()); ?> - <?php echo e($all_brand_product->lastItem()); ?>

            / <?php echo e($all_brand_product->total()); ?> Thương Hiệu
          </small>
        </div>

        <div class="col-sm-7 text-right text-center-xs">
          <?php echo e($all_brand_product->links('vendor.pagination.number-only')); ?>

        </div>
      </div>
    </footer>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('pages.admin_layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\demodongho\resources\views/admin/all_brand_product.blade.php ENDPATH**/ ?>