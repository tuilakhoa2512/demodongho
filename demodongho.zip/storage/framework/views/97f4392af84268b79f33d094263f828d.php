

<script>
    /**
     * Hiển thị SweetAlert + xóa history state
     * => tránh Back trình duyệt hiện lại popup
     */
    function showAlertOnce(options) {
        Swal.fire(Object.assign({
            width: 600,                 //  TĂNG SIZE POPUP
            padding: '1.5rem',
            confirmButtonText: 'OK',
            confirmButtonColor: '#D70018'
        }, options));

        // FIX BACK BUTTON (BFCache)
        if (window.history.replaceState) {
            window.history.replaceState(null, null, window.location.href);
        }
    }
</script>


<?php if(session('success')): ?>
<script>
document.addEventListener('DOMContentLoaded', function () {
    showAlertOnce({
        icon: 'success',
        title: 'Thành công',
        text: <?php echo json_encode(session('success'), 15, 512) ?>
    });
});
</script>
<?php endif; ?>


<?php if(session('error')): ?>
<script>
document.addEventListener('DOMContentLoaded', function () {
    showAlertOnce({
        icon: 'error',
        title: 'Lỗi',
        text: <?php echo json_encode(session('error'), 15, 512) ?>
    });
});
</script>
<?php endif; ?>


<?php if(session('warning')): ?>
<script>
document.addEventListener('DOMContentLoaded', function () {
    showAlertOnce({
        icon: 'warning',
        title: 'Cảnh báo',
        text: <?php echo json_encode(session('warning'), 15, 512) ?>
    });
});
</script>
<?php endif; ?>


<?php if(session('info')): ?>
<script>
document.addEventListener('DOMContentLoaded', function () {
    showAlertOnce({
        icon: 'info',
        title: 'Thông báo',
        text: <?php echo json_encode(session('info'), 15, 512) ?>
    });
});
</script>
<?php endif; ?>


<?php if($errors->any()): ?>
<script>
document.addEventListener('DOMContentLoaded', function () {
    showAlertOnce({
        icon: 'error',
        title: 'Dữ liệu không hợp lệ',
        html: `<?php echo implode('<br>', $errors->all()); ?>`
    });
});
</script>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\demodongho\resources\views/pages/partials/alert.blade.php ENDPATH**/ ?>