<?php $__env->startSection('admin_content'); ?>

<div class="table-agile-info">
    <div class="panel panel-default">
        <div class="panel-heading">
            Liệt Kê Loại Sản Phẩm
            <?php if($filterStatus == 1): ?>
                <small>(Trạng Thái: Hiện)</small>
            <?php elseif($filterStatus === "0"): ?>
                <small>(Trạng Thái: Ẩn)</small>
            <?php endif; ?>  
        </div>
        <?php if(session('message')): ?>
                            <script>
                                $(document).ready(function() {
                                    Swal.fire({
                                        icon: 'success',
                                        title: 'Thành công!',
                                        text: '<?php echo e(session('message')); ?>',
                                        confirmButtonText: 'OK'
                                    });
                                });
                            </script>
                        <?php endif; ?>
        <div class="row w3-res-tb">
            <div class="col-sm-5 m-b-xs">
            <form method="GET" action="<?php echo e(route('admin.allproducttype')); ?>" class="form-inline">
          <select name="status" class="input-sm form-control w-sm inline v-middle">
            <option value="">Lọc trạng thái (Tất cả)</option>
            <option value="1" <?php echo e(isset($filterStatus) && $filterStatus == 1 ? 'selected' : ''); ?>>Hiện</option>
            <option value="0" <?php echo e(isset($filterStatus) && $filterStatus == 0 ? 'selected' : ''); ?>>Ẩn</option>
          </select>

          <button type="submit" class="btn btn-sm btn-default" style="margin-left:5px;">
            Áp dụng
          </button>

        </form>             
            </div>
            <div class="col-sm-4"></div>
            <div class="col-sm-3">
                
            </div>
        </div>
        <div class="table-responsive">
            <table class="table table-striped b-t b-light">
                <thead>
                    <tr>
                        <th style="width:20px;">
                            <label class="i-checks m-b-none">
                                <input type="checkbox"><i></i>
                            </label>
                        </th>
                        <th>ID</th>
                        <th>Tên loại</th>
                        <th>Mô tả</th>
                        <th>Slug</th>
                        <th>Hiển Thị</th>
                        <th>Thao tác</th>
                        <th style="width:30px;"></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $all_product_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cate_pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><label class="i-checks m-b-none"><input type="checkbox" name="post[]"><i></i></label></td>
                        <td><?php echo e($cate_pro->id); ?></td>
                        <td><?php echo e($cate_pro->name); ?></td>
                        <td><?php echo e($cate_pro->description); ?></td>
                        <td><?php echo e($cate_pro->category_slug); ?></td>
                        <!-- <td><?php echo e($cate_pro->status); ?></td> -->
                        <td><span class="text-ellipsis">
                        <?php if($cate_pro->status == 1): ?>
                            <span class="label label-success">Hiện</span>
                        <?php else: ?>
                            <span class="label label-danger">Ẩn</span>
                        <?php endif; ?>
                        </span></td>
                        <td>
                            <a href="<?php echo e(URL::to('/edit-product-type/'.$cate_pro->id)); ?>" class="active styling edit">
                                <i class="fa fa-pencil-square-o text-success text-active"></i>
                            </a>
                            <!-- Thao tác Ẩn Hiện -->
                            <?php if($cate_pro->status == 1): ?>
                                <!-- Đang hiện → cho phép ẩn -->
                                <a href="<?php echo e(URL::to('/unactive-product-type/'.$cate_pro->id)); ?>" class="active styling edit" style="font-size: 18px;">
                                    <i class="fa fa-eye text-warning"></i>
                                </a>
                            <?php else: ?>
                                <!-- Đang ẩn → cho phép hiện -->
                                <a href="<?php echo e(URL::to('/active-product-type/'.$cate_pro->id)); ?>" class="active styling edit" style="font-size: 18px;">
                                    <i class="fa fa-eye-slash text-warning"></i>
                                </a>
                            <?php endif; ?>

                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        
<footer class="panel-footer">
      <div class="row">
        <div class="col-sm-5 text-center">
          <small class="text-muted inline m-t-sm m-b-sm">
            Hiển thị <?php echo e($all_product_type->firstItem()); ?> - <?php echo e($all_product_type->lastItem()); ?>

            / <?php echo e($all_product_type->total()); ?> Danh Mục
          </small>
        </div>

        <div class="col-sm-7 text-right text-center-xs">
          <?php echo e($all_product_type->links('vendor.pagination.number-only')); ?>

        </div>
      </div>
</footer>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('pages.admin_layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\demodongho\resources\views/admin/all_product_type.blade.php ENDPATH**/ ?>