<?php $__env->startSection('admin_content'); ?>

<div class="table-agile-info">
  <div class="panel panel-default">
    <div class="panel-heading">
      Danh sách lô hàng
       <?php if($filterStatus == 1): ?>
          <small>(Trạng Thái: Hiện)</small>
        <?php elseif($filterStatus === "0"): ?>
          <small>(Trạng Thái: Ẩn)</small>
        <?php endif; ?>
    </div>
   
    <?php if(session('success')): ?>
        <script>
            Swal.fire({
                title: "Thành công!",
                text: "<?php echo e(session('success')); ?>",
                icon: "success",
                confirmButtonText: "OK",
              
            });
        </script>
        <?php endif; ?>

    <!-- <?php if(session('success')): ?>
      <div class="alert alert-success" style="margin: 15px;">
        <?php echo e(session('success')); ?>

      </div>
    <?php endif; ?> -->

    <?php if(session('error')): ?>
      <div class="alert alert-danger" style="margin: 15px;">
        <?php echo e(session('error')); ?>

      </div>
    <?php endif; ?>

    <style>
        table td, table th {
            text-align: center !important;
            vertical-align: middle !important;
        }
    </style>


    <div class="row w3-res-tb">
      <div class="col-sm-5 m-b-xs">

        <form method="GET" action="<?php echo e(route('admin.storages.index')); ?>" class="form-inline">

          <select name="status" class="input-sm form-control w-sm inline v-middle">
            <option value="">Lọc trạng thái (Tất cả)</option>
            <option value="1" <?php echo e(isset($filterStatus) && $filterStatus == 1 ? 'selected' : ''); ?>>Hiện</option>
            <option value="0" <?php echo e(isset($filterStatus) && $filterStatus == 0 ? 'selected' : ''); ?>>Ẩn</option>
          </select>

          <button type="submit" class="btn btn-sm btn-default" style="margin-left:5px;">
            Áp dụng
          </button>

        </form>

      </div>

      <div class="col-sm-4">
      </div>

      <div class="col-sm-3">
        <div class="input-group">
        
        </div>
      </div>
    </div>

    <div class="table-responsive">
      <table class="table table-striped b-t b-light">
        <thead>
          <tr>
            <th style="width:20px;">
              <label class="i-checks m-b-none">
                <input type="checkbox"><i></i>
              </label>
            </th>
            <th>ID</th>
            <th>Mã lô</th>
            <th>Nhà cung cấp</th>
            <th>Email NCC</th>
            <th>Ngày nhập</th>
            <th>Trạng thái</th>
            <th style="width:140px;">Thao tác</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $storages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $storage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td>
                <label class="i-checks m-b-none">
                  <input type="checkbox" name="storage_ids[]" value="<?php echo e($storage->id); ?>"><i></i>
                </label>
              </td>

              <td><?php echo e($storage->id); ?></td>

              <td><?php echo e($storage->batch_code); ?></td>

              <td><?php echo e($storage->supplier_name ?? '—'); ?></td>

              <td><?php echo e($storage->supplier_email ?? '—'); ?></td>

              <td>
                <?php echo e($storage->import_date
                    ? \Carbon\Carbon::parse($storage->import_date)->format('d/m/Y')
                    : '—'); ?>

              </td>

              <td>
                <?php if($storage->status): ?>
                  <span class="label label-success">Hiện</span>
                <?php else: ?>
                  <span class="label label-default">Ẩn</span>
                <?php endif; ?>
              </td>

              <td>
                
                <a href="<?php echo e(route('admin.storages.edit', $storage->id)); ?>"
                   class="active styling-edit" title="Sửa lô hàng">
                  <i class="fa fa-pencil-square-o text-success text-active" style="font-size:18px;"></i>
                </a>

                
                <form action="<?php echo e(route('admin.storages.toggle-status', $storage->id)); ?>"
                      method="POST"
                      style="display:inline-block; margin:0 4px;">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('PATCH'); ?>
                  <button type="submit"
                          style="border:none; background:none; padding:0;"
                          title="<?php echo e($storage->status ? 'Ẩn lô hàng' : 'Hiện lô hàng'); ?>">
                    <?php if($storage->status): ?>
                      <i class="fa fa-eye-slash text-warning" style="font-size:18px;"></i>
                    <?php else: ?>
                      <i class="fa fa-eye text-info" style="font-size:18px;"></i>
                    <?php endif; ?>
                  </button>
                </form>

                
                <a href="<?php echo e(route('admin.storage-details.by-storage', $storage->id)); ?>"
                   title="Xem sản phẩm trong lô này">
                  <i class="fa fa-archive text-primary" style="font-size:18px;"></i>
                </a>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>

    <footer class="panel-footer">
      <div class="row">
        <div class="col-sm-5 text-center">
          <small class="text-muted inline m-t-sm m-b-sm">
            Hiển thị <?php echo e($storages->firstItem()); ?> - <?php echo e($storages->lastItem()); ?>

            / <?php echo e($storages->total()); ?> lô hàng
          </small>
        </div>

        <div class="text-center">
          <?php echo e($storages->links('vendor.pagination.number-only')); ?>

        </div>
      </div>
    </footer>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('pages.admin_layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\demodongho\resources\views/admin/storages/index.blade.php ENDPATH**/ ?>